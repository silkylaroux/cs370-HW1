README
======

This package includes the following files.

|-- Invoker.c [This is the driver program which will be used to invoke the get_running_ratio.]
|-- Analyze.c [Skeleton version of Analyze, in which you have to fill in the missing code.]
|-- Analyze.h [Header file declaring the function exposed from Analyze.c]
|-- README.txt [This file]

Use the provided makefile as a template.


